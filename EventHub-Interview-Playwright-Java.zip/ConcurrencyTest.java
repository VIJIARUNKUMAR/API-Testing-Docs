package com.qa.api.eventhub.interview;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * EH-33 and EH-34.
 * Playwright's request client is single-threaded, so the two calls at the same
 * time use Java's HTTP client. The setup event is still created with Playwright.
 */
public class ConcurrencyTest extends InterviewSupport {

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(20))
            .build();
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    public void eh33TwoDifferentUsersRegisterTogether() throws Exception {
        HttpRequest first = registerRequest(uniqueEmail());
        HttpRequest second = registerRequest(uniqueEmail());

        CompletableFuture<HttpResponse<String>> one = http.sendAsync(first, HttpResponse.BodyHandlers.ofString());
        CompletableFuture<HttpResponse<String>> two = http.sendAsync(second, HttpResponse.BodyHandlers.ofString());

        HttpResponse<String> firstResponse = one.get(30, TimeUnit.SECONDS);
        HttpResponse<String> secondResponse = two.get(30, TimeUnit.SECONDS);

        Assert.assertEquals(firstResponse.statusCode(), 201, firstResponse.body());
        Assert.assertEquals(secondResponse.statusCode(), 201, secondResponse.body());
    }

    @Test
    public void eh34TwoBookingsForTheLastSeatDoNotGoBelowZero() throws Exception {
        String token = register(uniqueEmail()).get("token").asText();
        int eventId = createEvent(token, eventBody(
                "Last seat", "one seat", "Concert", "Hall", "Mumbai", 80, 1));
        try {
            String ticket = mapper.writeValueAsString(Map.of(
                    "eventId", eventId,
                    "customerName", "Priya Sharma",
                    "customerEmail", "priya.sharma@email.com",
                    "customerPhone", "9876543210",
                    "quantity", 1
            ));
            HttpRequest book = bookingRequest(token, ticket);
            CompletableFuture<HttpResponse<String>> one = http.sendAsync(book, HttpResponse.BodyHandlers.ofString());
            CompletableFuture<HttpResponse<String>> two = http.sendAsync(book, HttpResponse.BodyHandlers.ofString());

            int firstStatus = one.get(30, TimeUnit.SECONDS).statusCode();
            int secondStatus = two.get(30, TimeUnit.SECONDS).statusCode();
            Assert.assertTrue(firstStatus == 201 || firstStatus == 400, "status was " + firstStatus);
            Assert.assertTrue(secondStatus == 201 || secondStatus == 400, "status was " + secondStatus);

            JsonNode event = read(api.get("/api/events/" + eventId, authorized(token)));
            Assert.assertTrue(event.get("data").get("availableSeats").asInt() >= 0);
        } finally {
            deleteEvent(token, eventId);
        }
    }

    private HttpRequest registerRequest(String email) throws Exception {
        String body = mapper.writeValueAsString(Map.of("email", email, "password", PASSWORD));
        return HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/api/auth/register"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
    }

    private HttpRequest bookingRequest(String token, String body) {
        return HttpRequest.newBuilder()
                .uri(URI.create(BASE_URL + "/api/bookings"))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .build();
    }
}
