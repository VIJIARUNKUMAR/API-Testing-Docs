package com.qa.api.eventhub.interview;

import com.fasterxml.jackson.databind.JsonNode;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * EH-24 to EH-32 and EH-35 to EH-38.
 * Three events share one search word so the shared catalog is not counted.
 */
public class PaginationFilterSortTest extends InterviewSupport {

    private String token;
    private String marker;
    private int workshopId;
    private int concertId;
    private int sportsId;

    @BeforeClass
    public void createThreeEvents() throws IOException {
        token = register(uniqueEmail()).get("token").asText();
        marker = "case-" + UUID.randomUUID().toString().substring(0, 8);
        workshopId = createEvent(token, eventBody(
                marker + " workshop", "desc-" + marker, "Workshop", "Hall A", "Chennai", 10, 5));
        concertId = createEvent(token, eventBody(
                marker + " concert", "music night", "Concert", "venue-" + marker, "Chennai", 40, 5));
        sportsId = createEvent(token, eventBody(
                marker + " sports", "match day", "Sports", "Stadium", "Hyderabad", 90, 5));
    }

    @AfterClass
    public void deleteThreeEvents() {
        deleteEvent(token, workshopId);
        deleteEvent(token, concertId);
        deleteEvent(token, sportsId);
    }

    @Test
    public void eh24ToEh26PagesSplitThreeEvents() throws IOException {
        JsonNode page1 = listEvents(token, "search=" + marker + "&page=1&limit=2");
        Assert.assertEquals(page1.get("data").size(), 2);
        Assert.assertEquals(page1.get("pagination").get("total").asInt(), 3);
        Assert.assertEquals(page1.get("pagination").get("page").asInt(), 1);
        Assert.assertEquals(page1.get("pagination").get("limit").asInt(), 2);
        Assert.assertEquals(page1.get("pagination").get("totalPages").asInt(), 2);

        JsonNode page2 = listEvents(token, "search=" + marker + "&page=2&limit=2");
        Assert.assertEquals(page2.get("data").size(), 1);
        Assert.assertEquals(page2.get("pagination").get("total").asInt(), 3);
        List<Integer> firstIds = ids(page1.get("data"));
        Assert.assertFalse(firstIds.contains(page2.get("data").get(0).get("id").asInt()));

        JsonNode page3 = listEvents(token, "search=" + marker + "&page=3&limit=2");
        Assert.assertEquals(page3.get("data").size(), 0);
        Assert.assertEquals(page3.get("pagination").get("total").asInt(), 3);
        Assert.assertEquals(page3.get("pagination").get("totalPages").asInt(), 2);
    }

    @Test
    public void eh27ToEh30FiltersKeepOnlyMatchingEvents() throws IOException {
        JsonNode workshop = listEvents(token, "search=" + marker + "&category=Workshop");
        Assert.assertEquals(workshop.get("pagination").get("total").asInt(), 1);
        Assert.assertEquals(workshop.get("data").get(0).get("id").asInt(), workshopId);

        JsonNode chennai = listEvents(token, "search=" + marker + "&city=chennai");
        Assert.assertEquals(chennai.get("pagination").get("total").asInt(), 2);
        for (JsonNode row : chennai.get("data")) {
            Assert.assertEquals(row.get("city").asText(), "Chennai");
        }

        JsonNode byDescription = listEvents(token, "search=desc-" + marker);
        Assert.assertEquals(byDescription.get("data").size(), 1);
        Assert.assertEquals(byDescription.get("data").get(0).get("id").asInt(), workshopId);

        JsonNode noMatch = listEvents(token, "search=" + marker + "&category=Sports&city=Chennai");
        Assert.assertEquals(noMatch.get("data").size(), 0);
        Assert.assertEquals(noMatch.get("pagination").get("total").asInt(), 0);
    }

    @Test
    public void eh31AndEh32NewestEventStaysFirst() throws IOException {
        JsonNode normal = listEvents(token, "search=" + marker + "&limit=10");
        Assert.assertEquals(ids(normal.get("data")), List.of(sportsId, concertId, workshopId));

        JsonNode priceSort = listEvents(token, "search=" + marker + "&sort=price&order=asc&limit=10");
        Assert.assertEquals(ids(priceSort.get("data")), List.of(sportsId, concertId, workshopId));
        List<Integer> prices = new ArrayList<>();
        for (JsonNode row : priceSort.get("data")) {
            prices.add(Integer.parseInt(row.get("price").asText()));
        }
        Assert.assertEquals(prices, List.of(90, 40, 10));
    }

    @Test
    public void eh35ToEh38OtherSortFieldsAreAlsoIgnored() throws IOException {
        List<Integer> newestFirst = List.of(sportsId, concertId, workshopId);

        JsonNode priceDesc = listEvents(token, "search=" + marker + "&sort=price&order=desc&limit=10");
        Assert.assertEquals(ids(priceDesc.get("data")), newestFirst);

        JsonNode titleAsc = listEvents(token, "search=" + marker + "&sort=title&order=asc&limit=10");
        Assert.assertEquals(ids(titleAsc.get("data")), newestFirst);

        JsonNode cityAsc = listEvents(token, "search=" + marker + "&sort=city&order=asc&limit=10");
        Assert.assertEquals(ids(cityAsc.get("data")), newestFirst);
        Assert.assertEquals(cityAsc.get("data").get(0).get("city").asText(), "Hyderabad");

        JsonNode page1 = listEvents(token, "search=" + marker + "&sort=title&order=asc&page=1&limit=2");
        JsonNode page2 = listEvents(token, "search=" + marker + "&sort=title&order=asc&page=2&limit=2");
        List<Integer> stitched = new ArrayList<>(ids(page1.get("data")));
        stitched.addAll(ids(page2.get("data")));
        Assert.assertEquals(stitched, newestFirst);
        Assert.assertTrue(stitched.get(0) > stitched.get(1));
        Assert.assertTrue(stitched.get(1) > stitched.get(2));
    }

    private List<Integer> ids(JsonNode data) {
        List<Integer> ids = new ArrayList<>();
        for (JsonNode row : data) {
            ids.add(row.get("id").asInt());
        }
        return ids;
    }
}
