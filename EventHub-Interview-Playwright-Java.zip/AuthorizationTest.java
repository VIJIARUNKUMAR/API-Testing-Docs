package com.qa.api.eventhub.interview;

import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.options.RequestOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

/**
 * EH-07 and EH-08. A missing or fake token must be rejected.
 */
public class AuthorizationTest extends InterviewSupport {

    @Test
    public void eh07EventsRequireAToken() throws IOException {
        APIResponse response = api.get("/api/events");

        Assert.assertEquals(response.status(), 401, response.text());
        Assert.assertEquals(read(response).get("error").asText(), "Unauthorized");
    }

    @Test
    public void eh08FakeTokenIsRejected() throws IOException {
        APIResponse response = api.get("/api/auth/me",
                RequestOptions.create().setHeader("Authorization", "Bearer not-a-token"));

        Assert.assertEquals(response.status(), 401, response.text());
        Assert.assertEquals(read(response).get("error").asText(), "Invalid or expired token");
    }
}
