package com.qa.api.eventhub;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.RequestOptions;
import io.qameta.allure.Step;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

public abstract class EventHubSupport {

    protected static final String BASE_URL = "https://api.eventhub.rahulshettyacademy.com";
    protected static final String PASSWORD = "secret12";

    protected Playwright playwright;
    protected APIRequestContext api;
    protected final ObjectMapper json = new ObjectMapper();

    @BeforeClass(alwaysRun = true)
    public void openApiClient() {
        playwright = Playwright.create();
        api = playwright.request().newContext(new APIRequest.NewContextOptions()
                .setBaseURL(BASE_URL));
    }

    @AfterClass(alwaysRun = true)
    public void closeApiClient() {
        if (api != null) {
            api.dispose();
        }
        if (playwright != null) {
            playwright.close();
        }
    }

    protected String uniqueEmail() {
        return "eventhub." + UUID.randomUUID() + "@example.com";
    }

    protected RequestOptions jsonBody(Map<String, ?> body) {
        return RequestOptions.create().setData(body);
    }

    protected RequestOptions authorized(String token) {
        return RequestOptions.create().setHeader("Authorization", "Bearer " + token);
    }

    protected RequestOptions authorized(String token, Map<String, ?> body) {
        return authorized(token).setData(body);
    }

    protected JsonNode read(APIResponse response) throws IOException {
        return json.readTree(response.body());
    }

    @Step("Register {email}")
    protected JsonNode register(String email) throws IOException {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("email", email);
        body.put("password", PASSWORD);
        APIResponse response = api.post("/api/auth/register", jsonBody(body));
        Assert.assertEquals(response.status(), 201, response.text());
        return read(response);
    }

    @Step("Log in as {email}")
    protected APIResponse login(String email, String password) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("email", email);
        body.put("password", password);
        return api.post("/api/auth/login", jsonBody(body));
    }

    protected Map<String, Object> eventPayload(String title, int price, int totalSeats) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("title", title);
        body.put("description", "Created by Playwright API tests");
        body.put("category", "Workshop");
        body.put("venue", "Hall A");
        body.put("city", "Bengaluru");
        body.put("eventDate", "2026-12-01T10:00:00.000Z");
        body.put("price", price);
        body.put("totalSeats", totalSeats);
        return body;
    }

    protected Map<String, Object> bookingPayload(int eventId, int quantity) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("eventId", eventId);
        body.put("customerName", "Ada Lovelace");
        body.put("customerEmail", "ada@example.com");
        body.put("customerPhone", "9876543210");
        body.put("quantity", quantity);
        return body;
    }
}
