package com.qa.api.eventhub.interview;

import com.fasterxml.jackson.databind.JsonNode;
import com.microsoft.playwright.APIResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * EH-09 to EH-15. Create an event, read it, replace it, then delete it.
 */
public class EventsTest extends InterviewSupport {

    @Test
    public void eh09CreateRejectsATitleOnlyBody() throws IOException {
        String token = register(uniqueEmail()).get("token").asText();
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("title", "Incomplete");

        APIResponse response = api.post("/api/events", authorized(token, body));

        Assert.assertEquals(response.status(), 400, response.text());
        Assert.assertEquals(read(response).get("error").asText(), "Validation failed");
        Assert.assertTrue(read(response).get("details").size() > 0);
    }

    @Test
    public void eh10ToEh15CreateReadUpdateAndDelete() throws IOException {
        String token = register(uniqueEmail()).get("token").asText();
        String title = "Interview workshop " + token.substring(0, 8);

        APIResponse created = api.post("/api/events", authorized(token,
                eventBody(title, "A workshop", "Workshop", "Hall A", "Chennai", 10, 5)));
        Assert.assertEquals(created.status(), 201, created.text());
        JsonNode event = read(created).get("data");
        int eventId = event.get("id").asInt();
        Assert.assertEquals(event.get("availableSeats").asInt(), 5);

        APIResponse fetched = api.get("/api/events/" + eventId, authorized(token));
        Assert.assertEquals(fetched.status(), 200, fetched.text());
        Assert.assertEquals(read(fetched).get("data").get("city").asText(), "Chennai");

        APIResponse missing = api.get("/api/events/99999999", authorized(token));
        Assert.assertEquals(missing.status(), 404, missing.text());

        APIResponse partial = api.put("/api/events/" + eventId, authorized(token, Map.of("title", "Only title")));
        Assert.assertEquals(partial.status(), 400, partial.text());

        APIResponse updated = api.put("/api/events/" + eventId, authorized(token,
                eventBody(title + " updated", "A workshop", "Workshop", "Hall B", "Chennai", 15, 5)));
        Assert.assertEquals(updated.status(), 200, updated.text());
        Assert.assertEquals(read(updated).get("data").get("venue").asText(), "Hall B");
        Assert.assertEquals(read(updated).get("data").get("price").asText(), "15");

        APIResponse deleted = api.delete("/api/events/" + eventId, authorized(token));
        Assert.assertEquals(deleted.status(), 200, deleted.text());
        Assert.assertEquals(read(deleted).get("message").asText(), "Event deleted successfully");

        APIResponse deletedAgain = api.delete("/api/events/" + eventId, authorized(token));
        Assert.assertEquals(deletedAgain.status(), 404, deletedAgain.text());
    }
}
