package com.qa.api.eventhub.interview;

import com.fasterxml.jackson.databind.JsonNode;
import com.microsoft.playwright.APIResponse;
import com.qa.api.eventhub.EventHubSupport;
import org.testng.Assert;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Shared setup for the interview suite.
 * Every event date is in 2027 so the API accepts it. A past date is rejected.
 */
public abstract class InterviewSupport extends EventHubSupport {

    protected static final String EVENT_DATE = "2027-12-01T10:00:00.000Z";

    protected Map<String, Object> eventBody(String title, String description, String category,
                                            String venue, String city, int price, int seats) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("title", title);
        body.put("description", description);
        body.put("category", category);
        body.put("venue", venue);
        body.put("city", city);
        body.put("eventDate", EVENT_DATE);
        body.put("price", price);
        body.put("totalSeats", seats);
        return body;
    }

    protected int createEvent(String token, Map<String, Object> body) throws IOException {
        APIResponse response = api.post("/api/events", authorized(token, body));
        Assert.assertEquals(response.status(), 201, response.text());
        return read(response).get("data").get("id").asInt();
    }

    protected void deleteEvent(String token, int eventId) {
        api.delete("/api/events/" + eventId, authorized(token));
    }

    protected JsonNode listEvents(String token, String query) throws IOException {
        APIResponse response = api.get("/api/events?" + query, authorized(token));
        Assert.assertEquals(response.status(), 200, response.text());
        return read(response);
    }
}
