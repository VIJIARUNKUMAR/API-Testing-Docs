package com.qa.api.eventhub.interview;

import com.fasterxml.jackson.databind.JsonNode;
import com.microsoft.playwright.APIResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * EH-01 to EH-06. Register, login, and the checks that should fail.
 */
public class AuthenticationTest extends InterviewSupport {

    @Test
    public void eh01RegisterReturnsToken() throws IOException {
        String email = uniqueEmail();
        APIResponse response = api.post("/api/auth/register", jsonBody(credentials(email, PASSWORD)));

        Assert.assertEquals(response.status(), 201, response.text());
        JsonNode body = read(response);
        Assert.assertTrue(body.get("success").asBoolean());
        Assert.assertFalse(body.get("token").asText().isEmpty());
        Assert.assertEquals(body.get("user").get("email").asText(), email);
    }

    @Test
    public void eh02LoginReturnsToken() throws IOException {
        String email = uniqueEmail();
        register(email);

        APIResponse response = login(email, PASSWORD);

        Assert.assertEquals(response.status(), 200, response.text());
        JsonNode body = read(response);
        Assert.assertTrue(body.get("success").asBoolean());
        Assert.assertEquals(body.get("user").get("email").asText(), email);
        Assert.assertFalse(body.get("token").asText().isEmpty());
    }

    @Test
    public void eh03CurrentUserMatchesTheToken() throws IOException {
        String email = uniqueEmail();
        String token = register(email).get("token").asText();

        APIResponse response = api.get("/api/auth/me", authorized(token));

        Assert.assertEquals(response.status(), 200, response.text());
        Assert.assertEquals(read(response).get("user").get("email").asText(), email);
    }

    @Test
    public void eh04SameEmailCannotRegisterTwice() throws IOException {
        String email = uniqueEmail();
        register(email);

        APIResponse second = api.post("/api/auth/register", jsonBody(credentials(email, PASSWORD)));

        Assert.assertEquals(second.status(), 400, second.text());
        Assert.assertEquals(read(second).get("error").asText(), "Email already registered");
    }

    @Test
    public void eh05ShortPasswordIsRejected() throws IOException {
        APIResponse response = api.post("/api/auth/register", jsonBody(credentials(uniqueEmail(), "abc")));

        Assert.assertEquals(response.status(), 400, response.text());
        Assert.assertEquals(read(response).get("error").asText(), "Validation failed");
        Assert.assertTrue(fieldNames(read(response)).contains("password"));
    }

    @Test
    public void eh06InvalidEmailIsRejected() throws IOException {
        APIResponse response = api.post("/api/auth/register", jsonBody(credentials("not-an-email", PASSWORD)));

        Assert.assertEquals(response.status(), 400, response.text());
        Assert.assertTrue(fieldNames(read(response)).contains("email"));
    }

    private Map<String, Object> credentials(String email, String password) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("email", email);
        body.put("password", password);
        return body;
    }

    private String fieldNames(JsonNode body) {
        StringBuilder names = new StringBuilder();
        for (JsonNode detail : body.get("details")) {
            names.append(detail.get("field").asText()).append(' ');
        }
        return names.toString();
    }
}
