package com.qa.api.eventhub.interview;

import com.fasterxml.jackson.databind.JsonNode;
import com.microsoft.playwright.APIResponse;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * EH-16 to EH-23.
 * GET /bookings is empty before a booking exists, has 1 row after create,
 * and is empty again after cancel because cancel deletes the row.
 */
public class BookingsTest extends InterviewSupport {

    @Test
    public void eh16ToEh23BookListAndCancel() throws IOException {
        String token = register(uniqueEmail()).get("token").asText();
        int eventId = createEvent(token, eventBody(
                "Booking workshop", "tickets", "Workshop", "Hall A", "Chennai", 10, 5));
        try {
            APIResponse before = api.get("/api/bookings?eventId=" + eventId, authorized(token));
            Assert.assertEquals(before.status(), 200, before.text());
            Assert.assertEquals(read(before).get("pagination").get("total").asInt(), 0);

            APIResponse booked = api.post("/api/bookings", authorized(token, ticket(eventId, 1)));
            Assert.assertEquals(booked.status(), 201, booked.text());
            JsonNode booking = read(booked).get("data");
            int bookingId = booking.get("id").asInt();
            Assert.assertEquals(booking.get("status").asText(), "confirmed");
            Assert.assertEquals(booking.get("quantity").asInt(), 1);
            Assert.assertEquals(booking.get("totalPrice").asText(), "10");

            Assert.assertEquals(seats(token, eventId), 4);

            APIResponse listed = api.get("/api/bookings?eventId=" + eventId, authorized(token));
            Assert.assertEquals(read(listed).get("pagination").get("total").asInt(), 1);
            Assert.assertEquals(read(listed).get("data").get(0).get("id").asInt(), bookingId);

            APIResponse byId = api.get("/api/bookings/" + bookingId, authorized(token));
            Assert.assertEquals(byId.status(), 200, byId.text());
            Assert.assertEquals(read(byId).get("data").get("quantity").asInt(), 1);

            APIResponse tooMany = api.post("/api/bookings", authorized(token, ticket(eventId, 10)));
            Assert.assertEquals(tooMany.status(), 400, tooMany.text());
            Assert.assertTrue(read(tooMany).get("error").asText().contains("available"));
            Assert.assertEquals(seats(token, eventId), 4);

            APIResponse cancelled = api.delete("/api/bookings/" + bookingId, authorized(token));
            Assert.assertEquals(cancelled.status(), 200, cancelled.text());
            Assert.assertEquals(read(cancelled).get("message").asText(), "Booking cancelled");

            APIResponse afterCancel = api.get("/api/bookings?eventId=" + eventId, authorized(token));
            Assert.assertEquals(read(afterCancel).get("data").size(), 0);
            Assert.assertEquals(read(afterCancel).get("pagination").get("total").asInt(), 0);
            Assert.assertEquals(seats(token, eventId), 5);
        } finally {
            deleteEvent(token, eventId);
        }
    }

    private Map<String, Object> ticket(int eventId, int quantity) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("eventId", eventId);
        body.put("customerName", "Priya Sharma");
        body.put("customerEmail", "priya.sharma@email.com");
        body.put("customerPhone", "9876543210");
        body.put("quantity", quantity);
        return body;
    }

    private int seats(String token, int eventId) throws IOException {
        APIResponse response = api.get("/api/events/" + eventId, authorized(token));
        Assert.assertEquals(response.status(), 200, response.text());
        return read(response).get("data").get("availableSeats").asInt();
    }
}
